jCaret
======

jQuery plugin to position the caret within text fields, textareas, and contentEditable elements
